package com.example.photomotion4k;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.*;
import android.content.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.util.Base64;
import android.widget.Toast;
import android.graphics.*;
import android.media.*;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import org.json.JSONObject;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private static final int PICK_IMAGE = 41;
    private ValueCallback<Uri[]> fileCallback;
    private volatile boolean rendering = false;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT); i.setType("image/*"); i.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(Intent.createChooser(i, "Pilih foto"), PICK_IMAGE); return true;
            }
        });
        web.addJavascriptInterface(new NativeBridge(), "PhotoMotionNative");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req,res,data);
        if (req == PICK_IMAGE && fileCallback != null) {
            Uri[] result = (res == RESULT_OK && data != null && data.getData() != null) ? new Uri[]{data.getData()} : null;
            fileCallback.onReceiveValue(result); fileCallback = null;
        }
    }

    private void notifyWeb(String message, int progress, boolean done) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript("window.nativeRenderUpdate && window.nativeRenderUpdate(" + progress + "," + JSONObject.quote(message) + "," + done + ")", null);
        });
    }

    private class NativeBridge {
        @JavascriptInterface public boolean isNativeMp4Available() { return true; }
        @JavascriptInterface public void renderMp4(String base64, String optionsJson) {
            if (rendering) { notifyWeb("Render sedang berjalan.", 0, false); return; }
            rendering = true;
            new Thread(() -> {
                try { renderVideo(base64, new JSONObject(optionsJson)); }
                catch (Throwable e) { notifyWeb("Render gagal: " + (e.getMessage()==null ? e.getClass().getSimpleName() : e.getMessage()), 0, true); }
                finally { rendering = false; }
            }, "PhotoMotion-Encoder").start();
        }
    }

    private void renderVideo(String encoded, JSONObject opts) throws Exception {
        notifyWeb("Menyiapkan foto dan encoder…", 0, false);
        byte[] source = Base64.decode(encoded, Base64.DEFAULT);
        BitmapFactory.Options bounds = new BitmapFactory.Options(); bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(source, 0, source.length, bounds);
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > 4096) sample *= 2;
        BitmapFactory.Options decode = new BitmapFactory.Options(); decode.inSampleSize = sample; decode.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap photo = BitmapFactory.decodeByteArray(source, 0, source.length, decode);
        if (photo == null) throw new Exception("Foto tidak dapat dibaca.");

        int width = opts.optInt("width", 2160), height = opts.optInt("height", 3840);
        int duration = opts.optInt("duration", 15), fps = opts.optInt("fps", 30);
        String motion = opts.optString("motion", "zoom");
        float intensity = (float)opts.optDouble("intensity", 1.0);
        if (width < 2 || height < 2 || (width & 1) != 0 || (height & 1) != 0) throw new Exception("Ukuran video harus genap.");
        if (width > 3840 || height > 3840) throw new Exception("Resolusi melebihi batas aplikasi.");

        String mime = "video/avc";
        MediaCodec codec = MediaCodec.createEncoderByType(mime);
        MediaCodecInfo.CodecCapabilities caps = codec.getCodecInfo().getCapabilitiesForType(mime);
        int colorFormat = chooseColorFormat(caps);
        MediaFormat format = MediaFormat.createVideoFormat(mime, width, height);
        format.setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat);
        format.setInteger(MediaFormat.KEY_BIT_RATE, Math.min(50000000, Math.max(6000000, width * height * fps / 7)));
        format.setInteger(MediaFormat.KEY_FRAME_RATE, fps);
        format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2);
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
        codec.start();

        ContentValues values = new ContentValues();
        String filename = "PhotoMotion_" + duration + "s_" + width + "x" + height + "_" + System.currentTimeMillis() + ".mp4";
        values.put(MediaStore.Video.Media.DISPLAY_NAME, filename);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        if (Build.VERSION.SDK_INT >= 29) values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/PhotoMotion4K");
        Uri outputUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (outputUri == null) { codec.stop(); codec.release(); throw new Exception("Tidak bisa membuat file video."); }
        ParcelFileDescriptor pfd = null; MediaMuxer muxer = null;
        boolean muxerStarted = false, completed = false;
        int track = -1;
        try {
            pfd = getContentResolver().openFileDescriptor(outputUri, "w");
            if (pfd == null) throw new Exception("Tidak bisa membuka file tujuan.");
            muxer = new MediaMuxer(pfd.getFileDescriptor(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            Bitmap frame = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(frame); Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            int[] pixels = new int[width * height];
            byte[] yuv = new byte[width * height * 3 / 2];
            int total = duration * fps;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            for (int i = 0; i < total; i++) {
                float p = total <= 1 ? 1f : (float)i / (float)(total - 1);
                drawMotionFrame(canvas, paint, photo, width, height, p, motion, intensity);
                frame.getPixels(pixels, 0, width, 0, 0, width, height);
                convertToYuv(pixels, width, height, yuv, colorFormat);
                int inputIndex = codec.dequeueInputBuffer(10000);
                while (inputIndex < 0) {
                    MuxState waitState = drainEncoder(codec, muxer, info, false, new MuxState(muxerStarted, track));
                    muxerStarted = waitState.started; track = waitState.track;
                    inputIndex = codec.dequeueInputBuffer(10000);
                }
                ByteBuffer input = codec.getInputBuffer(inputIndex);
                if (input == null || input.capacity() < yuv.length) throw new Exception("Buffer encoder terlalu kecil untuk resolusi ini. Coba 1080p.");
                input.clear(); input.put(yuv);
                codec.queueInputBuffer(inputIndex, 0, yuv.length, (long)i * 1000000L / fps, 0);
                MuxState state = drainEncoder(codec, muxer, info, false, new MuxState(muxerStarted, track));
                muxerStarted = state.started; track = state.track;
                if (i % Math.max(1, fps / 2) == 0) notifyWeb("Membuat MP4… " + Math.round((i + 1) * 100.0 / total) + "%", (i + 1) * 100 / total, false);
            }
            int eosIndex = codec.dequeueInputBuffer(10000);
            while (eosIndex < 0) { MuxState s = drainEncoder(codec, muxer, info, false, new MuxState(muxerStarted, track)); muxerStarted=s.started; track=s.track; eosIndex=codec.dequeueInputBuffer(10000); }
            codec.queueInputBuffer(eosIndex, 0, 0, (long)total * 1000000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
            boolean eos = false;
            while (!eos) {
                int out = codec.dequeueOutputBuffer(info, 10000);
                if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxerStarted) throw new Exception("Format encoder berubah lebih dari sekali.");
                    track = muxer.addTrack(codec.getOutputFormat()); muxer.start(); muxerStarted = true;
                } else if (out >= 0) {
                    ByteBuffer data = codec.getOutputBuffer(out);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (info.size > 0 && muxerStarted) { data.position(info.offset); data.limit(info.offset + info.size); muxer.writeSampleData(track, data, info); }
                    eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    codec.releaseOutputBuffer(out, false);
                }
            }
            if (!muxerStarted) throw new Exception("Encoder tidak menghasilkan stream MP4.");
            completed = true;
            frame.recycle();
        } finally {
            try { codec.stop(); } catch (Exception ignored) {} codec.release();
            if (muxer != null) { try { muxer.stop(); } catch (Exception ignored) {} muxer.release(); }
            if (pfd != null) pfd.close();
            photo.recycle();
            if (!completed) getContentResolver().delete(outputUri, null, null);
        }
        notifyWeb("Selesai! MP4 tersimpan di Movies/PhotoMotion4K.", 100, true);
        runOnUiThread(() -> Toast.makeText(MainActivity.this, "Video MP4 tersimpan di Movies/PhotoMotion4K", Toast.LENGTH_LONG).show());
    }

    private static class MuxState { boolean started; int track; MuxState(boolean s, int t) { started=s; track=t; } }
    private MuxState drainEncoder(MediaCodec codec, MediaMuxer muxer, MediaCodec.BufferInfo info, boolean end, MuxState state) throws Exception {
        while (true) {
            int out = codec.dequeueOutputBuffer(info, 0);
            if (out == MediaCodec.INFO_TRY_AGAIN_LATER) break;
            if (out == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                if (state.started) throw new Exception("Format encoder berubah.");
                state.track = muxer.addTrack(codec.getOutputFormat()); muxer.start(); state.started = true;
            } else if (out >= 0) {
                ByteBuffer data = codec.getOutputBuffer(out);
                if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                if (info.size > 0 && state.started) { data.position(info.offset); data.limit(info.offset + info.size); muxer.writeSampleData(state.track, data, info); }
                codec.releaseOutputBuffer(out, false);
                if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break;
            }
        }
        return state;
    }

    private int chooseColorFormat(MediaCodecInfo.CodecCapabilities caps) throws Exception {
        int[] preferred = {MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar};
        for (int p : preferred) for (int f : caps.colorFormats) if (f == p) return p;
        throw new Exception("Encoder H.264 HP tidak mendukung format YUV yang kompatibel di perangkat ini.");
    }

    private void convertToYuv(int[] argb, int width, int height, byte[] out, int colorFormat) {
        int frameSize = width * height, yIndex = 0, uvIndex = frameSize;
        boolean planar = colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar;
        int uPlane = frameSize, vPlane = frameSize + frameSize / 4;
        if (planar) { uPlane = frameSize; vPlane = frameSize + frameSize / 4; }
        for (int j = 0; j < height; j++) {
            for (int i = 0; i < width; i++) {
                int c = argb[j * width + i], r = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
                int y = ((66*r + 129*g + 25*b + 128) >> 8) + 16;
                out[yIndex++] = (byte)Math.max(0, Math.min(255, y));
                if ((j & 1) == 0 && (i & 1) == 0) {
                    int u = ((-38*r - 74*g + 112*b + 128) >> 8) + 128;
                    int v = ((112*r - 94*g - 18*b + 128) >> 8) + 128;
                    if (planar) { int pos = (j/2)*(width/2)+(i/2); out[uPlane+pos]=(byte)Math.max(0,Math.min(255,u)); out[vPlane+pos]=(byte)Math.max(0,Math.min(255,v)); }
                    else { out[uvIndex++] = (byte)Math.max(0,Math.min(255,u)); out[uvIndex++] = (byte)Math.max(0,Math.min(255,v)); }
                }
            }
        }
    }

    private void drawMotionFrame(Canvas canvas, Paint paint, Bitmap photo, int w, int h, float p, String motion, float intensity) {
        canvas.drawColor(Color.BLACK);
        float ease = p*p*(3f-2f*p);
        float base = Math.max((float)w/photo.getWidth(), (float)h/photo.getHeight());
        float zoom = "out".equals(motion) ? 1f + .16f*intensity*(1f-ease) : ("zoom".equals(motion) ? 1f + .16f*intensity*ease : 1f + .08f*intensity);
        float iw = photo.getWidth()*base*zoom, ih = photo.getHeight()*base*zoom;
        float dx = 0, dy = 0;
        if ("pan".equals(motion)) dx = (ease-.5f)*w*.12f*intensity;
        if ("drift".equals(motion)) { dx=(float)Math.sin(p*Math.PI*2)*w*.025f*intensity; dy=(float)Math.cos(p*Math.PI*2)*h*.018f*intensity; }
        RectF dst = new RectF((w-iw)/2f+dx, (h-ih)/2f+dy, (w+iw)/2f+dx, (h+ih)/2f+dy);
        canvas.drawBitmap(photo, null, dst, paint);
    }

    @Override public void onBackPressed() { if (web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
