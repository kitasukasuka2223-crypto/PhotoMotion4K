# Cara mendapatkan APK melalui GitHub Actions (bisa dari HP)

File ini menambahkan workflow cloud build. APK belum ada di ZIP ini; GitHub akan mengompilasinya setelah proyek diunggah ke repository milik Anda.

1. Buat akun / masuk ke https://github.com dari browser HP.
2. Buat repository baru bernama `PhotoMotion4K` (boleh Public atau Private).
3. Pada halaman repository, pilih **Add file → Upload files**.
4. Ekstrak ZIP proyek ini terlebih dahulu di HP, lalu unggah seluruh isi folder `PhotoMotion4K-v0.3.1` ke root repository. Pastikan folder `.github/workflows` ikut terunggah. Jika situs mobile tidak menampilkan file tersembunyi, aktifkan tampilan hidden files di file manager atau gunakan GitHub Desktop/PC.
5. Setelah upload selesai, buka tab **Actions** → workflow **Build PhotoMotion4K APK** → **Run workflow**.
6. Tunggu sampai proses berstatus hijau. Buka run tersebut, gulir ke **Artifacts**, lalu unduh `PhotoMotion4K-debug-apk`.
7. Ekstrak artifact ZIP dan instal file APK di POCO F6. Jika Android meminta izin, izinkan instalasi aplikasi dari browser/file manager yang digunakan.

Catatan:
- Ini menghasilkan debug APK untuk pengujian, bukan rilis Play Store.
- Pertahankan repository private jika tidak ingin source code terlihat publik.
- Build cloud memerlukan akun GitHub dan koneksi internet saat proses kompilasi.
- Proyek tetap dirancang agar aplikasi yang terpasang memproses foto secara offline.
