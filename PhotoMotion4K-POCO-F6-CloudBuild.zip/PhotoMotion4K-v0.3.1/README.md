# PhotoMotion 4K — v0.3.1 (Offline MP4 — POCO F6 preset)

A native Android project for turning a still photo into a short camera-motion video.

## Features in this version
- Runs locally on the Android device; no account, network service, API key, or subscription.
- Import one image from the device gallery.
- Camera motion presets: cinematic zoom in, slow zoom out, pan, and drift.
- Duration: 10 or 15 seconds.
- Aspect ratio: portrait 9:16, landscape 16:9, or square 1:1.
- Frame rate: 24 or 30 FPS.
- Native Android H.264 / MP4 export using `MediaCodec` and `MediaMuxer`.
- Output saved to `Movies/PhotoMotion4K` through Android MediaStore.
- Export sizes: preview 720p, Full HD 1080p, and 4K UHD (2160p short edge).
- POCO F6 / 8 GB preset: 1080p is selected by default; 4K remains selectable for device testing.

## Important limitations
- This version animates the camera framing (2D pan/zoom/drift). It does **not** use generative AI to make people, hair, water, clouds, or other objects move independently.
- AI object animation fully offline would require bundling a compatible on-device model; that is not included in this free starter project and may not run well on every phone.
- 4K encoding is device-dependent, including on POCO F6; this project has not been benchmarked on the user’s exact handset. Some phones do not expose a compatible H.264 encoder for 4K buffer input. On those devices, choose 1080p or Preview.
- 4K rendering can use substantial RAM, battery, storage, and CPU time. Close other apps, keep the phone cool, and test with Preview first.
- The app selects an H.264 YUV420 encoder format exposed by the device. If the phone exposes no compatible format, export will report an error rather than silently creating a corrupt file.

## Build APK
1. Open this folder in Android Studio (Giraffe or newer; Android Gradle Plugin 8.7.3).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Connect an Android device or use an emulator, then run the `app` configuration.
4. To build an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show the generated APK location after the build completes.

Minimum Android version: Android 8.0 (API 26).

## Privacy
Photo selection and rendering are performed locally. The app does not request Internet permission and does not upload the selected image.
